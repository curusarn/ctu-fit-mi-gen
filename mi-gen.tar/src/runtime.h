#ifndef RUNTIME_H
#define RUNTIME_H

extern "C" int read_();

extern "C" void write_(int what);

#endif
